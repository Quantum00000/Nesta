import { useState, useEffect } from 'react'
function App() {
  const [msg, setMsg] = useState('')
  useEffect(() => {
    fetch('/api/hello')
      .then(r => r.json())
      .then(data => setMsg(data.message))
      .catch(e => {
         fetch('/api/hello').then(r => r.text()).then(setMsg)
      })
  }, [])
  return (
    <div style={{fontFamily: 'sans-serif', padding: '2rem'}}>
      <h1>Generated MVP App</h1>
      <p>Backend says: {msg}</p>
    </div>
  )
}
export default App
